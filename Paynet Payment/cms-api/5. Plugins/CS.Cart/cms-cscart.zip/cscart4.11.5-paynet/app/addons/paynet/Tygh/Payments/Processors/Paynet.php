<?php
namespace Tygh\Payments\Processors;

use Tygh\Http;

class Paynet
{
    public $action = '';
    public $merchant;
    public $secret_key;
    public $api_login;
    public $api_pass;

    public function __construct($processor_data)
    {
        if ($processor_data['processor_params']['test_mode'] == 'enabled') {
            $this->action = "https://test.paynet.md/Acquiring/SetEcom";
        } else {
            $this->action = "https://paynet.md/Acquiring/SetEcom";
        }

        $this->merchant = $processor_data['processor_params']['merchant_code'];
        $this->secret_key = $processor_data['processor_params']['secret_key'];
        $this->api_login = $processor_data['processor_params']['api_login'];
        $this->api_pass = $processor_data['processor_params']['api_pass'];
    }

    public function prepareProducts($order_info)
    {
        $line_nr = 0;
        $array = [];
        foreach ($order_info['products'] as $item_id => $product) {
            $array[$line_nr]['Amount'] = $this->convertToMdl($product['price']);
            $array[$line_nr]['Barcode'] = $product['product_id'];
            $array[$line_nr]['Code'] = $product['product_id'];
            $array[$line_nr]['Description'] = strip_tags($product['product']);
            $array[$line_nr]['GroupId'] = $product['product_id']; // TODO: Get category id
            $array[$line_nr]['GroupName'] = strip_tags($product['product']); // TODO: Get category name
            $array[$line_nr]['LineNo'] = $line_nr;
            $array[$line_nr]['Name'] = strip_tags($product['product']);
            $array[$line_nr]['Quantity'] = $product['amount'];
            $array[$line_nr]['UnitPrice'] = $this->convertToMdl($product['base_price']);
            $array[$line_nr]['UnitProduct'] = 'pcs';

            $line_nr++;
        }

        /* If shipping cost is greater than 0, we must include it in products array */
        if($order_info['shipping_cost'] > 0){
        	foreach ($order_info['shipping'] as $shipping) {
	        	$array[$line_nr]['Amount'] = $this->convertToMdl($shipping['rate']);
	            $array[$line_nr]['Barcode'] = $shipping['shipping_id'];
	            $array[$line_nr]['Code'] = $shipping['shipping_id'];
	            $array[$line_nr]['Description'] = strip_tags($shipping['shipping']);
	            $array[$line_nr]['GroupId'] = $shipping['shipping_id'];
	            $array[$line_nr]['GroupName'] = 'Shipping';
	            $array[$line_nr]['LineNo'] = $line_nr;
	            $array[$line_nr]['Name'] = strip_tags($shipping['shipping']);
	            $array[$line_nr]['Quantity'] = '1';
	            $array[$line_nr]['UnitPrice'] = $this->convertToMdl($shipping['rate']);
	            $array[$line_nr]['UnitProduct'] = 'pcs';

	            $line_nr++;
        	}
        }

        return $array;
    }

    public function generateOrderIdPostfix()
    {
        return substr(number_format(microtime(true), 4, '', ''), -10); // last 10 digits
    }

    public function generateSignature($postData){
    	$prepared_string = "";
        $prepared_string .= $postData['Currency'];
        $prepared_string .= $postData['Customer.Address'].$postData['Customer.City'].$postData['Customer.Code'].$postData['Customer.Country'].$postData['Customer.email'].$postData['Customer.NameFirst'].$postData['Customer.NameLast'].$postData['Customer.PhoneNumber'];
        $prepared_string .= $postData['ExpiryDate'].strval($postData['ExternalID']).$postData['Merchant'].$postData['MoneyType.Code'];
        $prepared_string .= $postData['Services[0][Amount]'].$postData['Services[0][Description]'].$postData['Services[0][Name]'];
        foreach ($postData['Services[0][Products]'] as $line_nr => $product) {
        	foreach ($product as $key => $value) {
        		if($key != 'Quantity'){
        			$prepared_string .= $value;
        		}
        	}
        }
       
        $prepared_string .= $this->secret_key; 

        $signature = base64_encode(md5($prepared_string, true));

        return $signature;
    }

    public function createPaymentForm($postData){
        echo <<<EOT
        <form method="POST" action="$this->action" name="redirect">
EOT;

    $this->walkPostData($postData);

    echo <<<EOT
        <noscript><p>
EOT;
    echo(__('text_cc_javascript_disabled'));

    echo <<<EOT
        </p><p><input type="submit" name="btn" value="
EOT;
    echo(__('cc_button_submit'));
    echo <<<EOT
"></p>
        </noscript>
        </form>
        <script type="text/javascript">
            window.onload = function(){
                document.redirect.submit();
            };
        </script>
EOT;
    exit;

    }

    public function walkPostData($array, $field_name = "") {
        if(!is_array($array)) return;
        foreach ($array as $key => $value) {
            if(is_array($value)) {
                $this->walkPostData($value, empty($field_name) ? $key : $field_name."[".$key."]");
            } else {
                echo('<input type="hidden" name="' . htmlentities(empty($field_name) ? $key : $field_name."[".$key."]", ENT_QUOTES, 'UTF-8') . '" value="' . htmlentities($value, ENT_QUOTES, 'UTF-8') . '" />' . "<br>");
            }
        }
    }

    public function getPaynetApiAuthToken($api_url, $api_login, $api_password){
        $ch = curl_init($api_url . '/auth'); 
        header('Content-Type: application/json');
        $data = 'grant_type=password&username=' . $api_login . '&password=' . urlencode($api_password); 
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/x-www-form-urlencoded'));
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS,$data);
        $response_raw = curl_exec($ch);

        $this->writeLog('AUTH TOKEN REQUEST', $response_raw);

        if (curl_errno($ch)) {
            $error_msg = curl_error($ch);
        }

        curl_close($ch);

        if(isset($error_msg)){
            $this->writeLog('TOKEN REQUEST ERROR', $error_msg);
        }

        $response = json_decode($response_raw,true);

        if(isset($response['access_token'])){
            return $response['access_token'];
        } else {
            return false;
        }
    }

    public function checkPaynetPaymentStatus($api_url, $token, $payment_id){
        $ch = curl_init($api_url . '/api/Payments/' . $payment_id);
        header('Content-Type: application/json');
        $authorization = "Authorization: Bearer ".$token; // **Prepare Autorisation Token**
        curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json' , $authorization )); // **Inject Token into Header**
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);   
        $response_raw = curl_exec($ch);
        curl_close($ch);
        $this->writeLog('CHECK PAYMENT STATUS', $response_raw);
        $response = json_decode($response_raw,true);
        return $response['Status'];
    }

    public function writeLog($notification, $data, $file = 'paynet.log')
    {
        $path = fn_get_files_dir_path();
        fn_mkdir($path);
        $file = fopen($path . $file, 'a');

        if (!empty($file)) {
        	fputs($file, $notification . "\n");
            fputs($file, 'TIME: ' . date('Y-m-d H:i:s', TIME) . "\n");
            fputs($file, $data . "\n\n");
            fclose($file);
        }
    }

    public function convertToMdl($price)
    {
        if (CART_PRIMARY_CURRENCY != 'MDL') {
            $price = fn_format_price_by_currency($price, CART_PRIMARY_CURRENCY, 'MDL');
        }

        $price = fn_format_rate_value($price, 'F', 2, '', '', '');

        return $price;
    }
}
