<?php
use Tygh\Payments\Processors\Paynet;

if (defined('PAYMENT_NOTIFICATION')) {

    if ($mode == 'result') {
        $response_raw = file_get_contents("php://input");

        if(!empty($response_raw)){
            $response = json_decode($response_raw, true);
            $order_id = substr($response['Payment']['ExternalId'], 0, -10); //remove last 10 digits of postfix
            $payment_id = $response['Payment']['Id']; //payment id on paynet

            $order_info = fn_get_order_info($order_id);
            if (empty($processor_data) && !empty($order_info)) {
                $processor_data = fn_get_processor_data($order_info['payment_id']);
            }
            
            $paynet = new Paynet($processor_data);
            $paynet->writeLog('NOTIFICATION', $response_raw);

            if($response['EventType'] === 'PAID'){
                if($processor_data['processor_params']['test_mode'] == 'enabled'){
                    $apiUrl = 'https://test.paynet.md:4446';
                } else {
                    $apiUrl = 'https://paynet.md:4448';
                }

                $apiLogin = $paynet->api_login;
                $apiPassword = $paynet->api_pass;

                $token = $paynet->getPaynetApiAuthToken($apiUrl, $apiLogin, $apiPassword);
                if($token){
                    $status = $paynet->checkPaynetPaymentStatus($apiUrl, $token, $payment_id);
                }
                if(isset($status) && $status === 4){
                    $pp_response['order_status'] = "P"; // P - processed
                    $pp_response['reason_text'] = __('approved');
                    $pp_response['transaction_id'] = $payment_id;
                    fn_finish_payment($order_id, $pp_response);
                }
            }

        } else {
            $paynet = new Paynet($processor_data);
            $paynet->writeLog('NO INCOMING DATA DETECTED', "(empty)");
        }

        die('OK');
    }

    if($mode == 'return'){
        $order_id = substr($_GET['order_id'], 0, -10); //remove last 10 digits of postfix
        $times = 0;
        while ($times <= RK_MAX_AWAITING_TIME) {

            $_order_id = db_get_field("SELECT order_id FROM ?:order_data WHERE order_id = ?i AND type = 'S'", $order_id);
            if (empty($_order_id)) {
                break;
            }

            sleep(1);
            $times++;
        }

        $order_status = db_get_field("SELECT status FROM ?:orders WHERE order_id = ?i", $order_id);
        if ($order_status == STATUS_INCOMPLETED_ORDER) {
            $pp_response = array();
            $pp_response['order_status'] = 'F'; // F - failed
            $pp_response['reason_text'] = __('merchant_response_was_not_received');
            $pp_response['transaction_id'] = '';
            fn_finish_payment($order_id, $pp_response);
        }
        fn_order_placement_routines('route', $order_id, false);
    }

    if($mode == 'cancel'){
        $order_id = substr($_GET['order_id'], 0, -10); //remove last 10 digits of postfix
        $pp_response['order_status'] = 'D'; // D - cancelled
        $pp_response['reason_text'] = __('text_transaction_cancelled');
        fn_finish_payment($order_id, $pp_response);
        fn_order_placement_routines('route', $order_id, false);
    }

} else {
    date_default_timezone_set('Europe/Chisinau');

    $paynet = new Paynet($processor_data);

    $merchant_code = $paynet->merchant;

    $service_name = 'Casacurata.md';
    $service_description = 'Payment for purchases';
    $language = CART_LANGUAGE;
    $currency = '498'; // 498 - numeric code for MDL
    $order_id = (int) $order_info['order_id'].$paynet->generateOrderIdPostfix();
    $total = $paynet->convertToMdl($order_info['total']); // Price must be transmited to paynet only in MDL
    $date = strtotime("+2 hour");
    $date_expire = date('Y-m-d', $date).'T'.date('H:i:s', $date);

    if(isset($payment_info['selected_payment_type']) && !empty($payment_info['selected_payment_type'])){
        $money_type = $payment_info['selected_payment_type'];
    } else {
        $money_type = 'VISA_AND_MASTER_MDL';
    }

    /* Build products array with right structure */
    $products = $paynet->prepareProducts($order_info);

    /* Prepare data for building payment form */
    $postData['ExternalID'] = $order_id;
    $postData['Merchant'] = $merchant_code;
    $postData['Currency'] = $currency;
    $postData['Services[0][Name]'] = $service_name;
    $postData['Services[0][Description]'] = $service_description;
    $postData['Services[0][Amount]'] = $total;
    $postData['Services[0][Products]'] = $products;

    $postData['Customer.Code'] = !empty($order_info['user_id']) ? $order_info['user_id'] : 0;
    $postData['Customer.NameFirst'] = !empty($order_info['b_firstname']) ? $order_info['b_firstname'] : 'Not set';
    $postData['Customer.NameLast'] = !empty($order_info['b_lastname']) ? $order_info['b_lastname'] : 'Not set';
    $postData['Customer.PhoneNumber'] = !empty($order_info['b_phone']) ? $order_info['b_phone'] : 'Not set';
    $postData['Customer.email'] = $order_info['email'];
    $postData['Customer.Country'] = !empty($order_info['b_country_descr']) ? $order_info['b_country_descr'] : 'Not set';
    $postData['Customer.City'] = !empty($order_info['b_city']) ? $order_info['b_city'] : 'Not set';
    $postData['Customer.Address'] = !empty($order_info['b_address']) ? $order_info['b_address'] : 'Not set';

    $postData['ExternalDate'] = $date;
    $postData['ExpiryDate'] = $date_expire;
    $postData['LinkUrlSuccess'] = 'https://'.$_SERVER['HTTP_HOST'].'/index.php?dispatch=payment_notification.return&payment=paynet&order_id='.$order_id;
    $postData['LinkUrlCancel'] = 'https://'.$_SERVER['HTTP_HOST'].'/index.php?dispatch=payment_notification.cancel&payment=paynet&order_id='.$order_id;
    $postData['Lang'] = $language;
    $postData['SignVersion'] = 'v05';
    $postData['MoneyType.Code'] = $money_type;
    $postData['Signature'] = $paynet->generateSignature($postData);
    
    $paynet->createPaymentForm($postData);

    die();
}

