<?php
if (!defined('BOOTSTRAP')) { die('Access denied'); }

function fn_paynet_install()
{
    fn_paynet_uninstall();

    $_data = array(
        'processor' => 'Paynet',
        'processor_script' => 'paynet.php',
        'processor_template' => 'addons/paynet/views/orders/components/payments/paynet.tpl',
        'admin_template' => 'paynet.tpl',
        'callback' => 'N',
        'type' => 'P',
        'addon' => 'paynet'
    );

    db_query("INSERT INTO ?:payment_processors ?e", $_data);
}

function fn_paynet_uninstall()
{
    db_query("DELETE FROM ?:payment_processors WHERE processor_script = ?s", "paynet.php");
}


